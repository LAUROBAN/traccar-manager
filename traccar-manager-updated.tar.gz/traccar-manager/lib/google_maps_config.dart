/// Configuração do Google Maps para o Traccar Manager
/// 
/// Este arquivo contém as constantes e configurações necessárias para
/// integrar o Google Maps, Street View e API de Direções.

class GoogleMapsConfig {
  /// Chave de API do Google Maps
  /// 
  /// IMPORTANTE: Substitua com sua própria chave de API do Google Cloud Console
  /// 1. Acesse https://console.cloud.google.com/
  /// 2. Crie um novo projeto
  /// 3. Ative as APIs: Maps SDK for Android, Maps SDK for iOS, Street View Static API, Directions API
  /// 4. Crie uma chave de API
  /// 5. Restrinja a chave para Android e iOS conforme necessário
  static const String googleMapsApiKey = 'YOUR_GOOGLE_MAPS_API_KEY_HERE';

  /// Zoom padrão do mapa
  static const double defaultZoom = 15.0;

  /// Zoom mínimo do mapa
  static const double minZoom = 2.0;

  /// Zoom máximo do mapa
  static const double maxZoom = 20.0;

  /// Cor padrão para marcadores
  static const String defaultMarkerColor = '#FF0000';

  /// Cor padrão para polilinhas de rota
  static const String defaultPolylineColor = '#0066FF';

  /// Espessura padrão das polilinhas
  static const int defaultPolylineWidth = 5;

  /// Modo de transporte padrão para direções
  static const String defaultTravelMode = 'DRIVING';

  /// Tempo de atualização de localização em segundos
  static const int locationUpdateInterval = 5;

  /// Distância mínima para atualizar localização em metros
  static const int locationMinDistance = 10;
}
