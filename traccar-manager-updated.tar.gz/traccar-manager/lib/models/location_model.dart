import 'package:google_maps_flutter/google_maps_flutter.dart';

/// Modelo para representar uma localização
class LocationData {
  final double latitude;
  final double longitude;
  final String? title;
  final String? description;
  final DateTime? timestamp;
  final double? accuracy;
  final double? altitude;
  final double? speed;
  final double? heading;

  LocationData({
    required this.latitude,
    required this.longitude,
    this.title,
    this.description,
    this.timestamp,
    this.accuracy,
    this.altitude,
    this.speed,
    this.heading,
  });

  /// Converte para LatLng do Google Maps
  LatLng toLatLng() => LatLng(latitude, longitude);

  /// Cria a partir de LatLng
  factory LocationData.fromLatLng(LatLng latLng, {String? title, String? description}) {
    return LocationData(
      latitude: latLng.latitude,
      longitude: latLng.longitude,
      title: title,
      description: description,
    );
  }

  @override
  String toString() => 'LocationData(lat: $latitude, lng: $longitude, title: $title)';
}

/// Modelo para representar uma rota
class RouteData {
  final String id;
  final LocationData origin;
  final LocationData destination;
  final List<LocationData> waypoints;
  final String travelMode;
  final double? distance;
  final Duration? duration;
  final List<LatLng>? polylinePoints;
  final String? encodedPolyline;
  final DateTime createdAt;

  RouteData({
    required this.id,
    required this.origin,
    required this.destination,
    this.waypoints = const [],
    this.travelMode = 'DRIVING',
    this.distance,
    this.duration,
    this.polylinePoints,
    this.encodedPolyline,
    required this.createdAt,
  });

  /// Calcula a distância em km
  String get distanceKm => distance != null ? '${(distance! / 1000).toStringAsFixed(2)} km' : 'N/A';

  /// Formata a duração
  String get durationFormatted {
    if (duration == null) return 'N/A';
    final hours = duration!.inHours;
    final minutes = duration!.inMinutes % 60;
    if (hours > 0) {
      return '${hours}h ${minutes}m';
    }
    return '${minutes}m';
  }

  @override
  String toString() => 'RouteData(id: $id, from: ${origin.title}, to: ${destination.title})';
}

/// Modelo para representar um dispositivo rastreado
class TrackedDevice {
  final String id;
  final String name;
  final LocationData currentLocation;
  final List<LocationData> locationHistory;
  final bool isOnline;
  final DateTime? lastUpdate;
  final String? status;

  TrackedDevice({
    required this.id,
    required this.name,
    required this.currentLocation,
    this.locationHistory = const [],
    this.isOnline = false,
    this.lastUpdate,
    this.status,
  });

  @override
  String toString() => 'TrackedDevice(id: $id, name: $name, online: $isOnline)';
}
