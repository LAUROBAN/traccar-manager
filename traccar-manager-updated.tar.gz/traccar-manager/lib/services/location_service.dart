import 'dart:developer' as developer;
import 'package:geolocator/geolocator.dart';
import 'package:traccar_manager/google_maps_config.dart';
import 'package:traccar_manager/models/location_model.dart';

/// Serviço para gerenciar localização do dispositivo
class LocationService {
  static final LocationService _instance = LocationService._internal();

  factory LocationService() {
    return _instance;
  }

  LocationService._internal();

  LocationSettings get _locationSettings => LocationSettings(
    accuracy: LocationAccuracy.best,
    distanceFilter: GoogleMapsConfig.locationMinDistance,
    timeLimit: Duration(seconds: GoogleMapsConfig.locationUpdateInterval),
  );

  /// Verifica se o serviço de localização está ativado
  Future<bool> isLocationServiceEnabled() async {
    try {
      return await Geolocator.isLocationServiceEnabled();
    } catch (e) {
      developer.log('Erro ao verificar serviço de localização', error: e);
      return false;
    }
  }

  /// Solicita permissão de localização
  Future<LocationPermission> requestLocationPermission() async {
    try {
      final permission = await Geolocator.requestPermission();
      return permission;
    } catch (e) {
      developer.log('Erro ao solicitar permissão de localização', error: e);
      return LocationPermission.denied;
    }
  }

  /// Verifica se a permissão de localização foi concedida
  Future<bool> hasLocationPermission() async {
    try {
      final permission = await Geolocator.checkPermission();
      return permission == LocationPermission.whileInUse || 
             permission == LocationPermission.always;
    } catch (e) {
      developer.log('Erro ao verificar permissão de localização', error: e);
      return false;
    }
  }

  /// Obtém a localização atual
  Future<LocationData?> getCurrentLocation() async {
    try {
      final hasPermission = await hasLocationPermission();
      if (!hasPermission) {
        developer.log('Permissão de localização não concedida');
        return null;
      }

      final position = await Geolocator.getCurrentPosition(
        locationSettings: _locationSettings,
      );

      return LocationData(
        latitude: position.latitude,
        longitude: position.longitude,
        accuracy: position.accuracy,
        altitude: position.altitude,
        speed: position.speed,
        heading: position.heading,
        timestamp: DateTime.fromMillisecondsSinceEpoch(position.timestamp?.millisecondsSinceEpoch ?? 0),
      );
    } catch (e) {
      developer.log('Erro ao obter localização atual', error: e);
      return null;
    }
  }

  /// Obtém um stream contínuo de atualizações de localização
  Stream<LocationData> getLocationStream() async* {
    try {
      final hasPermission = await hasLocationPermission();
      if (!hasPermission) {
        developer.log('Permissão de localização não concedida');
        return;
      }

      final positionStream = Geolocator.getPositionStream(
        locationSettings: _locationSettings,
      );

      await for (final position in positionStream) {
        yield LocationData(
          latitude: position.latitude,
          longitude: position.longitude,
          accuracy: position.accuracy,
          altitude: position.altitude,
          speed: position.speed,
          heading: position.heading,
          timestamp: DateTime.fromMillisecondsSinceEpoch(position.timestamp?.millisecondsSinceEpoch ?? 0),
        );
      }
    } catch (e) {
      developer.log('Erro ao obter stream de localização', error: e);
    }
  }

  /// Calcula a distância entre dois pontos em metros
  static Future<double> getDistance(
    double startLatitude,
    double startLongitude,
    double endLatitude,
    double endLongitude,
  ) async {
    try {
      return await Geolocator.distanceBetween(
        startLatitude,
        startLongitude,
        endLatitude,
        endLongitude,
      );
    } catch (e) {
      developer.log('Erro ao calcular distância', error: e);
      return 0;
    }
  }

  /// Abre as configurações de localização do dispositivo
  Future<bool> openLocationSettings() async {
    try {
      return await Geolocator.openLocationSettings();
    } catch (e) {
      developer.log('Erro ao abrir configurações de localização', error: e);
      return false;
    }
  }

  /// Abre as configurações de aplicativo do dispositivo
  Future<bool> openAppSettings() async {
    try {
      return await Geolocator.openAppSettings();
    } catch (e) {
      developer.log('Erro ao abrir configurações de aplicativo', error: e);
      return false;
    }
  }
}
