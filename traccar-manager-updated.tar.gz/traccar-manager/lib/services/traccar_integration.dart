import 'dart:developer' as developer;
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:traccar_manager/models/location_model.dart';

/// Serviço para integração com Traccar Server
/// 
/// Este serviço permite comunicação com o servidor Traccar para obter
/// dados de dispositivos, posições e histórico de localização.
class TraccarIntegrationService {
  static final TraccarIntegrationService _instance = TraccarIntegrationService._internal();
  
  late String _serverUrl;
  late String _authToken;
  late http.Client _httpClient;

  factory TraccarIntegrationService() {
    return _instance;
  }

  TraccarIntegrationService._internal() {
    _httpClient = http.Client();
  }

  /// Inicializa o serviço com URL do servidor e token de autenticação
  void initialize({
    required String serverUrl,
    required String authToken,
  }) {
    _serverUrl = serverUrl;
    _authToken = authToken;
  }

  /// Obtém lista de dispositivos do servidor
  Future<List<TrackedDevice>> getDevices() async {
    try {
      final response = await _httpClient.get(
        Uri.parse('$_serverUrl/api/devices'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((device) {
          return TrackedDevice(
            id: device['id'].toString(),
            name: device['name'] ?? 'Dispositivo',
            currentLocation: LocationData(
              latitude: device['latitude'] ?? 0,
              longitude: device['longitude'] ?? 0,
            ),
            isOnline: device['status'] == 'online',
            lastUpdate: DateTime.parse(device['lastUpdate'] ?? DateTime.now().toString()),
            status: device['status'],
          );
        }).toList();
      } else {
        developer.log('Erro ao obter dispositivos: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      developer.log('Erro ao obter dispositivos', error: e);
      return [];
    }
  }

  /// Obtém posição atual de um dispositivo
  Future<LocationData?> getDevicePosition(String deviceId) async {
    try {
      final response = await _httpClient.get(
        Uri.parse('$_serverUrl/api/devices/$deviceId'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return LocationData(
          latitude: data['latitude'] ?? 0,
          longitude: data['longitude'] ?? 0,
          title: data['name'],
          timestamp: DateTime.parse(data['lastUpdate'] ?? DateTime.now().toString()),
          speed: (data['speed'] ?? 0).toDouble(),
          heading: (data['course'] ?? 0).toDouble(),
        );
      } else {
        developer.log('Erro ao obter posição: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      developer.log('Erro ao obter posição do dispositivo', error: e);
      return null;
    }
  }

  /// Obtém histórico de localização de um dispositivo
  Future<List<LocationData>> getDeviceHistory({
    required String deviceId,
    required DateTime from,
    required DateTime to,
  }) async {
    try {
      final params = {
        'deviceId': deviceId,
        'from': from.toIso8601String(),
        'to': to.toIso8601String(),
      };

      final response = await _httpClient.get(
        Uri.parse('$_serverUrl/api/positions').replace(queryParameters: params),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.map((position) {
          return LocationData(
            latitude: position['latitude'] ?? 0,
            longitude: position['longitude'] ?? 0,
            timestamp: DateTime.parse(position['deviceTime'] ?? DateTime.now().toString()),
            speed: (position['speed'] ?? 0).toDouble(),
            heading: (position['course'] ?? 0).toDouble(),
            accuracy: (position['accuracy'] ?? 0).toDouble(),
            altitude: (position['altitude'] ?? 0).toDouble(),
          );
        }).toList();
      } else {
        developer.log('Erro ao obter histórico: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      developer.log('Erro ao obter histórico de localização', error: e);
      return [];
    }
  }

  /// Obtém lista de geofences do servidor
  Future<List<Map<String, dynamic>>> getGeofences() async {
    try {
      final response = await _httpClient.get(
        Uri.parse('$_serverUrl/api/geofences'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.cast<Map<String, dynamic>>();
      } else {
        developer.log('Erro ao obter geofences: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      developer.log('Erro ao obter geofences', error: e);
      return [];
    }
  }

  /// Obtém eventos de um dispositivo
  Future<List<Map<String, dynamic>>> getEvents({
    required String deviceId,
    required DateTime from,
    required DateTime to,
  }) async {
    try {
      final params = {
        'deviceId': deviceId,
        'from': from.toIso8601String(),
        'to': to.toIso8601String(),
      };

      final response = await _httpClient.get(
        Uri.parse('$_serverUrl/api/events').replace(queryParameters: params),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = jsonDecode(response.body);
        return data.cast<Map<String, dynamic>>();
      } else {
        developer.log('Erro ao obter eventos: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      developer.log('Erro ao obter eventos', error: e);
      return [];
    }
  }

  /// Envia uma posição para o servidor
  Future<bool> sendPosition(LocationData position) async {
    try {
      final response = await _httpClient.post(
        Uri.parse('$_serverUrl/api/positions'),
        headers: _getHeaders(),
        body: jsonEncode({
          'deviceId': 'mobile_device',
          'latitude': position.latitude,
          'longitude': position.longitude,
          'accuracy': position.accuracy,
          'altitude': position.altitude,
          'speed': position.speed,
          'course': position.heading,
          'timestamp': DateTime.now().toIso8601String(),
        }),
      );

      return response.statusCode == 200;
    } catch (e) {
      developer.log('Erro ao enviar posição', error: e);
      return false;
    }
  }

  /// Testa a conexão com o servidor
  Future<bool> testConnection() async {
    try {
      final response = await _httpClient.get(
        Uri.parse('$_serverUrl/api/server'),
        headers: _getHeaders(),
      ).timeout(const Duration(seconds: 5));

      return response.statusCode == 200;
    } catch (e) {
      developer.log('Erro ao testar conexão', error: e);
      return false;
    }
  }

  /// Obtém informações do servidor
  Future<Map<String, dynamic>?> getServerInfo() async {
    try {
      final response = await _httpClient.get(
        Uri.parse('$_serverUrl/api/server'),
        headers: _getHeaders(),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        developer.log('Erro ao obter informações do servidor: ${response.statusCode}');
        return null;
      }
    } catch (e) {
      developer.log('Erro ao obter informações do servidor', error: e);
      return null;
    }
  }

  /// Obtém headers padrão para requisições
  Map<String, String> _getHeaders() {
    return {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $_authToken',
    };
  }

  /// Fecha a conexão
  void dispose() {
    _httpClient.close();
  }
}
