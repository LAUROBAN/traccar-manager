import 'dart:developer' as developer;
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:google_directions_api/google_directions_api.dart';
import 'package:traccar_manager/google_maps_config.dart';
import 'package:traccar_manager/models/location_model.dart';

/// Serviço para obter direções e rotas usando Google Directions API
class DirectionsService {
  static final DirectionsService _instance = DirectionsService._internal();
  late final GoogleDirectionsApi _directionsApi;

  factory DirectionsService() {
    return _instance;
  }

  DirectionsService._internal() {
    _directionsApi = GoogleDirectionsApi(
      apiKey: GoogleMapsConfig.googleMapsApiKey,
    );
  }

  /// Obtém a rota entre dois pontos
  Future<RouteData?> getRoute({
    required LocationData origin,
    required LocationData destination,
    List<LocationData> waypoints = const [],
    String travelMode = 'DRIVING',
  }) async {
    try {
      final response = await _directionsApi.directionsWithLocation(
        DirectionsRequest(
          origin: LatLng(origin.latitude, origin.longitude),
          destination: LatLng(destination.latitude, destination.longitude),
          travelMode: travelMode,
          waypoints: waypoints.map((w) => LatLng(w.latitude, w.longitude)).toList(),
          alternatives: false,
        ),
      );

      if (response.isOkay && response.routes.isNotEmpty) {
        final route = response.routes.first;
        final leg = route.legs.first;

        // Decodifica a polilinha
        final polylinePoints = _decodePolyline(route.overviewPolyline.points);

        return RouteData(
          id: '${origin.latitude},${origin.longitude}_${destination.latitude},${destination.longitude}',
          origin: origin,
          destination: destination,
          waypoints: waypoints,
          travelMode: travelMode,
          distance: leg.distance.value.toDouble(),
          duration: Duration(seconds: leg.duration.value),
          polylinePoints: polylinePoints,
          encodedPolyline: route.overviewPolyline.points,
          createdAt: DateTime.now(),
        );
      } else {
        developer.log('Erro na resposta da API: ${response.errorMessage}');
        return null;
      }
    } catch (e) {
      developer.log('Erro ao obter rota', error: e);
      return null;
    }
  }

  /// Decodifica uma polilinha codificada
  List<LatLng> _decodePolyline(String encoded) {
    List<LatLng> polylineCoordinates = [];
    int index = 0, len = encoded.length;
    int lat = 0, lng = 0;

    while (index < len) {
      int b, shift = 0, result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlat = ((result & 1) != 0) ? ~(result >> 1) : (result >> 1);
      lat += dlat;

      shift = 0;
      result = 0;
      do {
        b = encoded.codeUnitAt(index++) - 63;
        result |= (b & 0x1f) << shift;
        shift += 5;
      } while (b >= 0x20);
      int dlng = ((result & 1) != 0) ? ~(result >> 1) : (result >> 1);
      lng += dlng;

      double latitude = (lat / 1e5).toDouble();
      double longitude = (lng / 1e5).toDouble();
      polylineCoordinates.add(LatLng(latitude, longitude));
    }

    return polylineCoordinates;
  }

  /// Obtém múltiplas rotas alternativas
  Future<List<RouteData>> getAlternativeRoutes({
    required LocationData origin,
    required LocationData destination,
    String travelMode = 'DRIVING',
  }) async {
    try {
      final response = await _directionsApi.directionsWithLocation(
        DirectionsRequest(
          origin: LatLng(origin.latitude, origin.longitude),
          destination: LatLng(destination.latitude, destination.longitude),
          travelMode: travelMode,
          alternatives: true,
        ),
      );

      if (response.isOkay && response.routes.isNotEmpty) {
        return response.routes.map((route) {
          final leg = route.legs.first;
          final polylinePoints = _decodePolyline(route.overviewPolyline.points);

          return RouteData(
            id: '${origin.latitude},${origin.longitude}_${destination.latitude},${destination.longitude}_${response.routes.indexOf(route)}',
            origin: origin,
            destination: destination,
            travelMode: travelMode,
            distance: leg.distance.value.toDouble(),
            duration: Duration(seconds: leg.duration.value),
            polylinePoints: polylinePoints,
            encodedPolyline: route.overviewPolyline.points,
            createdAt: DateTime.now(),
          );
        }).toList();
      } else {
        developer.log('Erro na resposta da API: ${response.errorMessage}');
        return [];
      }
    } catch (e) {
      developer.log('Erro ao obter rotas alternativas', error: e);
      return [];
    }
  }

  /// Calcula a matriz de distâncias entre múltiplos pontos
  Future<Map<String, dynamic>?> getDistanceMatrix({
    required List<LocationData> origins,
    required List<LocationData> destinations,
    String travelMode = 'DRIVING',
  }) async {
    try {
      // Nota: Esta é uma implementação simplificada
      // Para usar a Distance Matrix API, você precisará de uma biblioteca adicional
      // ou fazer chamadas HTTP diretas à API
      
      developer.log('Distance Matrix API não implementada nesta versão');
      return null;
    } catch (e) {
      developer.log('Erro ao obter matriz de distâncias', error: e);
      return null;
    }
  }
}
