import 'package:flutter/material.dart';
import 'package:traccar_manager/models/location_model.dart';

/// Tela para exibir detalhes de uma rota
class RouteDetailsScreen extends StatefulWidget {
  final RouteData route;

  const RouteDetailsScreen({
    Key? key,
    required this.route,
  }) : super(key: key);

  @override
  State<RouteDetailsScreen> createState() => _RouteDetailsScreenState();
}

class _RouteDetailsScreenState extends State<RouteDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalhes da Rota'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Informações principais
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Resumo da Rota',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 16),
                    _buildInfoRow('Distância:', widget.route.distanceKm),
                    const SizedBox(height: 8),
                    _buildInfoRow('Tempo Estimado:', widget.route.durationFormatted),
                    const SizedBox(height: 8),
                    _buildInfoRow('Modo de Transporte:', widget.route.travelMode),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Origem
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Origem',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    if (widget.route.origin.title != null)
                      Text(
                        widget.route.origin.title!,
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    Text(
                      '${widget.route.origin.latitude.toStringAsFixed(6)}, ${widget.route.origin.longitude.toStringAsFixed(6)}',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Destino
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Destino',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    if (widget.route.destination.title != null)
                      Text(
                        widget.route.destination.title!,
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    Text(
                      '${widget.route.destination.latitude.toStringAsFixed(6)}, ${widget.route.destination.longitude.toStringAsFixed(6)}',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Pontos intermediários (se houver)
            if (widget.route.waypoints.isNotEmpty) ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Pontos Intermediários',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 8),
                      ...widget.route.waypoints.asMap().entries.map((entry) {
                        final index = entry.key + 1;
                        final waypoint = entry.value;
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Ponto $index',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '${waypoint.latitude.toStringAsFixed(6)}, ${waypoint.longitude.toStringAsFixed(6)}',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Informações adicionais
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Informações Adicionais',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    _buildInfoRow(
                      'ID da Rota:',
                      widget.route.id,
                      isMonospace: true,
                    ),
                    const SizedBox(height: 8),
                    _buildInfoRow(
                      'Criada em:',
                      _formatDateTime(widget.route.createdAt),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Botões de ação
            SizedBox(
              width: double.infinity,
              child: Column(
                children: [
                  ElevatedButton.icon(
                    onPressed: () {
                      // Copiar informações da rota
                      _copyRouteInfo();
                    },
                    icon: const Icon(Icons.copy),
                    label: const Text('Copiar Informações'),
                  ),
                  const SizedBox(height: 8),
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    icon: const Icon(Icons.close),
                    label: const Text('Fechar'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, {bool isMonospace = false}) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            value,
            style: isMonospace
              ? Theme.of(context).textTheme.bodyMedium?.copyWith(
                  fontFamily: 'monospace',
                )
              : Theme.of(context).textTheme.bodyMedium,
            softWrap: true,
          ),
        ),
      ],
    );
  }

  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.day}/${dateTime.month}/${dateTime.year} ${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  void _copyRouteInfo() {
    final info = '''
Rota: ${widget.route.origin.title} → ${widget.route.destination.title}
Distância: ${widget.route.distanceKm}
Tempo: ${widget.route.durationFormatted}
Modo: ${widget.route.travelMode}
Origem: ${widget.route.origin.latitude.toStringAsFixed(6)}, ${widget.route.origin.longitude.toStringAsFixed(6)}
Destino: ${widget.route.destination.latitude.toStringAsFixed(6)}, ${widget.route.destination.longitude.toStringAsFixed(6)}
''';

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Informações copiadas')),
    );
  }
}
