import 'dart:async';
import 'dart:developer' as developer;
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:traccar_manager/google_maps_config.dart';
import 'package:traccar_manager/models/location_model.dart';
import 'package:traccar_manager/services/location_service.dart';
import 'package:traccar_manager/services/directions_service.dart';
import 'package:traccar_manager/screens/street_view_screen.dart';
import 'package:traccar_manager/screens/route_details_screen.dart';

/// Tela principal com Google Maps integrado
class MapScreen extends StatefulWidget {
  final String? deviceId;
  final String? deviceName;

  const MapScreen({
    Key? key,
    this.deviceId,
    this.deviceName,
  }) : super(key: key);

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  late GoogleMapController _mapController;
  late LocationService _locationService;
  late DirectionsService _directionsService;

  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};
  
  LocationData? _currentLocation;
  LocationData? _selectedLocation;
  RouteData? _currentRoute;
  
  StreamSubscription<LocationData>? _locationSubscription;
  bool _isLoading = false;
  bool _showRouteDetails = false;

  @override
  void initState() {
    super.initState();
    _locationService = LocationService();
    _directionsService = DirectionsService();
    _initializeMap();
  }

  Future<void> _initializeMap() async {
    try {
      // Verifica permissões de localização
      final hasPermission = await _locationService.hasLocationPermission();
      if (!hasPermission) {
        final permission = await _locationService.requestLocationPermission();
        if (permission.isDenied) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Permissão de localização negada')),
            );
          }
          return;
        }
      }

      // Obtém localização atual
      final location = await _locationService.getCurrentLocation();
      if (location != null && mounted) {
        setState(() {
          _currentLocation = location;
        });

        // Move câmera para localização atual
        _mapController.animateCamera(
          CameraUpdateOptions(
            bounds: CameraUpdateBounds(
              bounds: LatLngBounds(
                southwest: LatLng(location.latitude - 0.01, location.longitude - 0.01),
                northeast: LatLng(location.latitude + 0.01, location.longitude + 0.01),
              ),
            ),
          ),
        );

        // Adiciona marcador de localização atual
        _addMarker(
          location,
          title: 'Minha Localização',
          color: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        );

        // Inicia stream de localização
        _startLocationUpdates();
      }
    } catch (e) {
      developer.log('Erro ao inicializar mapa', error: e);
    }
  }

  void _startLocationUpdates() {
    _locationSubscription = _locationService.getLocationStream().listen(
      (location) {
        if (mounted) {
          setState(() {
            _currentLocation = location;
          });
          
          // Atualiza marcador de localização atual
          _updateMarker(
            location,
            title: 'Minha Localização',
            color: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          );
        }
      },
      onError: (error) {
        developer.log('Erro no stream de localização', error: error);
      },
    );
  }

  void _addMarker(
    LocationData location, {
    required String title,
    required BitmapDescriptor color,
  }) {
    final marker = Marker(
      markerId: MarkerId(title),
      position: location.toLatLng(),
      infoWindow: InfoWindow(
        title: title,
        snippet: location.description ?? '${location.latitude}, ${location.longitude}',
      ),
      icon: color,
      onTap: () {
        _onMarkerTap(location);
      },
    );

    setState(() {
      _markers.removeWhere((m) => m.markerId.value == title);
      _markers.add(marker);
    });
  }

  void _updateMarker(
    LocationData location, {
    required String title,
    required BitmapDescriptor color,
  }) {
    _addMarker(location, title: title, color: color);
  }

  void _onMarkerTap(LocationData location) {
    setState(() {
      _selectedLocation = location;
    });

    // Mostra bottom sheet com opções
    _showLocationBottomSheet(location);
  }

  void _showLocationBottomSheet(LocationData location) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              location.title ?? 'Localização',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              '${location.latitude.toStringAsFixed(6)}, ${location.longitude.toStringAsFixed(6)}',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            if (_currentLocation != null)
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  _getRoute(_currentLocation!, location);
                },
                icon: const Icon(Icons.directions),
                label: const Text('Traçar Rota'),
              ),
            const SizedBox(height: 8),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
                _openStreetView(location);
              },
              icon: const Icon(Icons.streetview),
              label: const Text('Street View'),
            ),
            const SizedBox(height: 8),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: const Icon(Icons.close),
              label: const Text('Fechar'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _getRoute(LocationData origin, LocationData destination) async {
    try {
      setState(() => _isLoading = true);

      final route = await _directionsService.getRoute(
        origin: origin,
        destination: destination,
        travelMode: GoogleMapsConfig.defaultTravelMode,
      );

      if (route != null && mounted) {
        setState(() {
          _currentRoute = route;
          _drawRoute(route);
        });

        // Mostra detalhes da rota
        if (mounted) {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => RouteDetailsScreen(route: route),
            ),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Erro ao obter rota')),
          );
        }
      }
    } catch (e) {
      developer.log('Erro ao obter rota', error: e);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro: ${e.toString()}')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _drawRoute(RouteData route) {
    if (route.polylinePoints == null || route.polylinePoints!.isEmpty) {
      return;
    }

    final polyline = Polyline(
      polylineId: PolylineId(route.id),
      points: route.polylinePoints!,
      color: Colors.blue,
      width: GoogleMapsConfig.defaultPolylineWidth,
      geodesic: true,
    );

    setState(() {
      _polylines.clear();
      _polylines.add(polyline);
    });

    // Ajusta câmera para mostrar toda a rota
    _fitRouteBounds(route);
  }

  void _fitRouteBounds(RouteData route) {
    if (route.polylinePoints == null || route.polylinePoints!.isEmpty) {
      return;
    }

    double minLat = route.polylinePoints!.first.latitude;
    double maxLat = route.polylinePoints!.first.latitude;
    double minLng = route.polylinePoints!.first.longitude;
    double maxLng = route.polylinePoints!.first.longitude;

    for (final point in route.polylinePoints!) {
      minLat = minLat > point.latitude ? point.latitude : minLat;
      maxLat = maxLat < point.latitude ? point.latitude : maxLat;
      minLng = minLng > point.longitude ? point.longitude : minLng;
      maxLng = maxLng < point.longitude ? point.longitude : maxLng;
    }

    _mapController.animateCamera(
      CameraUpdateOptions(
        bounds: CameraUpdateBounds(
          bounds: LatLngBounds(
            southwest: LatLng(minLat, minLng),
            northeast: LatLng(maxLat, maxLng),
          ),
        ),
      ),
    );
  }

  void _openStreetView(LocationData location) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => StreetViewScreen(location: location),
      ),
    );
  }

  void _onMapTap(LatLng latLng) {
    final newLocation = LocationData.fromLatLng(
      latLng,
      title: 'Localização Selecionada',
      description: '${latLng.latitude.toStringAsFixed(6)}, ${latLng.longitude.toStringAsFixed(6)}',
    );

    _addMarker(
      newLocation,
      title: 'Localização Selecionada',
      color: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
    );

    _onMarkerTap(newLocation);
  }

  void _clearRoute() {
    setState(() {
      _currentRoute = null;
      _polylines.clear();
    });
  }

  @override
  void dispose() {
    _locationSubscription?.cancel();
    _mapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.deviceName ?? 'Mapa'),
        actions: [
          if (_currentRoute != null)
            IconButton(
              icon: const Icon(Icons.clear),
              onPressed: _clearRoute,
              tooltip: 'Limpar Rota',
            ),
        ],
      ),
      body: Stack(
        children: [
          GoogleMap(
            onMapCreated: (controller) {
              _mapController = controller;
            },
            initialCameraPosition: CameraPosition(
              target: _currentLocation?.toLatLng() ?? const LatLng(0, 0),
              zoom: GoogleMapsConfig.defaultZoom,
            ),
            markers: _markers,
            polylines: _polylines,
            onTap: _onMapTap,
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
            zoomControlsEnabled: true,
            mapType: MapType.normal,
            minMaxZoomPreference: MinMaxZoomPreference(
              GoogleMapsConfig.minZoom,
              GoogleMapsConfig.maxZoom,
            ),
          ),
          if (_isLoading)
            const Center(
              child: CircularProgressIndicator(),
            ),
        ],
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            heroTag: 'center_location',
            onPressed: () async {
              final location = await _locationService.getCurrentLocation();
              if (location != null) {
                _mapController.animateCamera(
                  CameraUpdateOptions(
                    bounds: CameraUpdateBounds(
                      bounds: LatLngBounds(
                        southwest: LatLng(location.latitude - 0.01, location.longitude - 0.01),
                        northeast: LatLng(location.latitude + 0.01, location.longitude + 0.01),
                      ),
                    ),
                  ),
                );
              }
            },
            tooltip: 'Centralizar em Minha Localização',
            child: const Icon(Icons.my_location),
          ),
          const SizedBox(height: 16),
          FloatingActionButton(
            heroTag: 'street_view',
            onPressed: () {
              if (_currentLocation != null) {
                _openStreetView(_currentLocation!);
              }
            },
            tooltip: 'Street View',
            child: const Icon(Icons.streetview),
          ),
        ],
      ),
    );
  }
}
