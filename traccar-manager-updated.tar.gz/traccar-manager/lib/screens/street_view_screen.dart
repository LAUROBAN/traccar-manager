import 'dart:developer' as developer;
import 'package:flutter/material.dart';
import 'package:flutter_google_street_view/flutter_google_street_view.dart';
import 'package:traccar_manager/models/location_model.dart';

/// Tela para visualizar Street View de uma localização
class StreetViewScreen extends StatefulWidget {
  final LocationData location;

  const StreetViewScreen({
    Key? key,
    required this.location,
  }) : super(key: key);

  @override
  State<StreetViewScreen> createState() => _StreetViewScreenState();
}

class _StreetViewScreenState extends State<StreetViewScreen> {
  late FlutterGoogleStreetViewController _streetViewController;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _initializeStreetView();
  }

  void _initializeStreetView() {
    try {
      // O Street View será inicializado quando o widget for criado
      setState(() {
        _isLoading = false;
      });
    } catch (e) {
      developer.log('Erro ao inicializar Street View', error: e);
      setState(() {
        _error = e.toString();
        _isLoading = false;
      });
    }
  }

  void _onStreetViewCreated(FlutterGoogleStreetViewController controller) {
    _streetViewController = controller;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Street View'),
        subtitle: Text(
          '${widget.location.latitude.toStringAsFixed(4)}, ${widget.location.longitude.toStringAsFixed(4)}',
          style: const TextStyle(fontSize: 12),
        ),
      ),
      body: Stack(
        children: [
          FlutterGoogleStreetView(
            onStreetViewCreated: _onStreetViewCreated,
            initialStreetViewPosition: StreetViewPanoramaCamera(
              bearing: 0,
              tilt: 0,
              zoom: 1.0,
            ),
            onStreetViewPositionChanged: (StreetViewPanoramaCamera camera) {
              developer.log(
                'Street View Position Changed: bearing=${camera.bearing}, tilt=${camera.tilt}, zoom=${camera.zoom}',
              );
            },
            strLatitude: widget.location.latitude,
            strLongitude: widget.location.longitude,
            strZoom: 1.0,
            onPanoramaLoadingListener: () {
              developer.log('Panorama carregando...');
            },
          ),
          if (_isLoading)
            const Center(
              child: CircularProgressIndicator(),
            ),
          if (_error != null)
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error, color: Colors.red, size: 48),
                  const SizedBox(height: 16),
                  Text('Erro: $_error'),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Voltar'),
                  ),
                ],
              ),
            ),
          // Controles de câmera
          Positioned(
            bottom: 16,
            right: 16,
            child: Column(
              children: [
                FloatingActionButton(
                  mini: true,
                  onPressed: () {
                    _streetViewController.animateTo(
                      duration: const Duration(milliseconds: 500),
                      camera: StreetViewPanoramaCamera(
                        bearing: 0,
                        tilt: 0,
                        zoom: 1.0,
                      ),
                    );
                  },
                  tooltip: 'Resetar Câmera',
                  child: const Icon(Icons.refresh),
                ),
                const SizedBox(height: 8),
                FloatingActionButton(
                  mini: true,
                  onPressed: () {
                    _streetViewController.animateTo(
                      duration: const Duration(milliseconds: 500),
                      camera: StreetViewPanoramaCamera(
                        bearing: 0,
                        tilt: 45,
                        zoom: 1.0,
                      ),
                    );
                  },
                  tooltip: 'Inclinar para Cima',
                  child: const Icon(Icons.arrow_upward),
                ),
                const SizedBox(height: 8),
                FloatingActionButton(
                  mini: true,
                  onPressed: () {
                    _streetViewController.animateTo(
                      duration: const Duration(milliseconds: 500),
                      camera: StreetViewPanoramaCamera(
                        bearing: 0,
                        tilt: -45,
                        zoom: 1.0,
                      ),
                    );
                  },
                  tooltip: 'Inclinar para Baixo',
                  child: const Icon(Icons.arrow_downward),
                ),
              ],
            ),
          ),
          // Informações de localização
          Positioned(
            top: 16,
            left: 16,
            right: 16,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (widget.location.title != null)
                      Text(
                        widget.location.title!,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                    if (widget.location.title != null)
                      const SizedBox(height: 4),
                    Text(
                      '${widget.location.latitude.toStringAsFixed(6)}, ${widget.location.longitude.toStringAsFixed(6)}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    if (widget.location.description != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        widget.location.description!,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}
