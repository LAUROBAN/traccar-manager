import 'dart:developer' as developer;
import 'package:traccar_manager/models/location_model.dart';
import 'package:traccar_manager/google_maps_config.dart';

/// Utilitário para gerenciar Street View
class StreetViewHelper {
  /// Gera URL para imagem estática de Street View
  static String getStreetViewImageUrl({
    required double latitude,
    required double longitude,
    int width = 600,
    int height = 400,
    int zoom = 1,
    int heading = 0,
    int pitch = 0,
  }) {
    return 'https://maps.googleapis.com/maps/api/streetview'
        '?size=${width}x$height'
        '&location=$latitude,$longitude'
        '&heading=$heading'
        '&pitch=$pitch'
        '&zoom=$zoom'
        '&key=${GoogleMapsConfig.googleMapsApiKey}';
  }

  /// Gera URL para Street View panorama
  static String getStreetViewPanoramaUrl({
    required double latitude,
    required double longitude,
  }) {
    return 'https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=$latitude,$longitude';
  }

  /// Verifica se uma localização tem cobertura de Street View
  static Future<bool> hasStreetViewCoverage(LocationData location) async {
    try {
      // Esta é uma verificação simplificada
      // Em produção, você deveria fazer uma chamada à API para verificar
      developer.log('Verificando cobertura de Street View para ${location.latitude}, ${location.longitude}');
      
      // Retorna true por padrão (a API retornará erro se não houver cobertura)
      return true;
    } catch (e) {
      developer.log('Erro ao verificar cobertura de Street View', error: e);
      return false;
    }
  }

  /// Gera coordenadas de câmera para diferentes ângulos
  static Map<String, dynamic> getCameraAngles(String angle) {
    switch (angle.toLowerCase()) {
      case 'front':
        return {'heading': 0, 'pitch': 0, 'zoom': 1.0};
      case 'back':
        return {'heading': 180, 'pitch': 0, 'zoom': 1.0};
      case 'left':
        return {'heading': 270, 'pitch': 0, 'zoom': 1.0};
      case 'right':
        return {'heading': 90, 'pitch': 0, 'zoom': 1.0};
      case 'up':
        return {'heading': 0, 'pitch': 45, 'zoom': 1.0};
      case 'down':
        return {'heading': 0, 'pitch': -45, 'zoom': 1.0};
      default:
        return {'heading': 0, 'pitch': 0, 'zoom': 1.0};
    }
  }

  /// Formata coordenadas para exibição
  static String formatCoordinates(LocationData location) {
    return '${location.latitude.toStringAsFixed(6)}, ${location.longitude.toStringAsFixed(6)}';
  }

  /// Obtém descrição de localização
  static String getLocationDescription(LocationData location) {
    final buffer = StringBuffer();
    
    if (location.title != null) {
      buffer.writeln('Título: ${location.title}');
    }
    
    buffer.writeln('Coordenadas: ${formatCoordinates(location)}');
    
    if (location.accuracy != null) {
      buffer.writeln('Precisão: ${location.accuracy!.toStringAsFixed(2)} m');
    }
    
    if (location.altitude != null) {
      buffer.writeln('Altitude: ${location.altitude!.toStringAsFixed(2)} m');
    }
    
    if (location.speed != null) {
      buffer.writeln('Velocidade: ${(location.speed! * 3.6).toStringAsFixed(2)} km/h');
    }
    
    if (location.heading != null) {
      buffer.writeln('Direção: ${location.heading!.toStringAsFixed(2)}°');
    }
    
    if (location.timestamp != null) {
      buffer.writeln('Hora: ${location.timestamp!.toString()}');
    }
    
    return buffer.toString();
  }
}
