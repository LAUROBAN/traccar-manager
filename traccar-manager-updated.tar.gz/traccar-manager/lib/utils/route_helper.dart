import 'dart:developer' as developer;
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:traccar_manager/models/location_model.dart';

/// Utilitário para gerenciar rotas e polilinhas
class RouteHelper {
  /// Calcula a distância total de uma rota em km
  static double calculateTotalDistance(List<LatLng> points) {
    if (points.length < 2) return 0;
    
    double totalDistance = 0;
    for (int i = 0; i < points.length - 1; i++) {
      totalDistance += _haversineDistance(points[i], points[i + 1]);
    }
    return totalDistance;
  }

  /// Calcula a distância entre dois pontos usando fórmula de Haversine
  static double _haversineDistance(LatLng point1, LatLng point2) {
    const double earthRadiusKm = 6371;
    
    final dLat = _degreesToRadians(point2.latitude - point1.latitude);
    final dLng = _degreesToRadians(point2.longitude - point1.longitude);
    
    final a = (Math.sin(dLat / 2) * Math.sin(dLat / 2)) +
        (Math.cos(_degreesToRadians(point1.latitude)) *
            Math.cos(_degreesToRadians(point2.latitude)) *
            Math.sin(dLng / 2) *
            Math.sin(dLng / 2));
    
    final c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return earthRadiusKm * c;
  }

  /// Converte graus para radianos
  static double _degreesToRadians(double degrees) {
    return degrees * (3.14159265359 / 180);
  }

  /// Formata distância para exibição
  static String formatDistance(double distanceMeters) {
    if (distanceMeters < 1000) {
      return '${distanceMeters.toStringAsFixed(0)} m';
    } else {
      return '${(distanceMeters / 1000).toStringAsFixed(2)} km';
    }
  }

  /// Formata duração para exibição
  static String formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes % 60;
    final seconds = duration.inSeconds % 60;
    
    if (hours > 0) {
      return '${hours}h ${minutes}m ${seconds}s';
    } else if (minutes > 0) {
      return '${minutes}m ${seconds}s';
    } else {
      return '${seconds}s';
    }
  }

  /// Calcula a velocidade média em km/h
  static double calculateAverageSpeed(double distanceMeters, Duration duration) {
    if (duration.inSeconds == 0) return 0;
    final speedMeterPerSecond = distanceMeters / duration.inSeconds;
    return speedMeterPerSecond * 3.6; // Converter para km/h
  }

  /// Obtém o ponto central de uma rota
  static LatLng getCenterPoint(List<LatLng> points) {
    if (points.isEmpty) {
      return const LatLng(0, 0);
    }
    
    double avgLat = 0;
    double avgLng = 0;
    
    for (final point in points) {
      avgLat += point.latitude;
      avgLng += point.longitude;
    }
    
    avgLat /= points.length;
    avgLng /= points.length;
    
    return LatLng(avgLat, avgLng);
  }

  /// Obtém os limites da rota (bounds)
  static LatLngBounds getBounds(List<LatLng> points) {
    if (points.isEmpty) {
      return LatLngBounds(
        southwest: const LatLng(0, 0),
        northeast: const LatLng(0, 0),
      );
    }
    
    double minLat = points.first.latitude;
    double maxLat = points.first.latitude;
    double minLng = points.first.longitude;
    double maxLng = points.first.longitude;
    
    for (final point in points) {
      minLat = Math.min(minLat, point.latitude);
      maxLat = Math.max(maxLat, point.latitude);
      minLng = Math.min(minLng, point.longitude);
      maxLng = Math.max(maxLng, point.longitude);
    }
    
    return LatLngBounds(
      southwest: LatLng(minLat, minLng),
      northeast: LatLng(maxLat, maxLng),
    );
  }

  /// Simplifica uma polilinha removendo pontos desnecessários
  static List<LatLng> simplifyPolyline(List<LatLng> points, {double tolerance = 0.00001}) {
    if (points.length < 3) return points;
    
    final simplified = <LatLng>[];
    simplified.add(points.first);
    
    for (int i = 1; i < points.length - 1; i++) {
      final distance = _perpendicularDistance(points[i], points[simplified.length - 1], points[i + 1]);
      if (distance > tolerance) {
        simplified.add(points[i]);
      }
    }
    
    simplified.add(points.last);
    return simplified;
  }

  /// Calcula a distância perpendicular de um ponto a uma linha
  static double _perpendicularDistance(LatLng point, LatLng lineStart, LatLng lineEnd) {
    final x = point.latitude;
    final y = point.longitude;
    final x1 = lineStart.latitude;
    final y1 = lineStart.longitude;
    final x2 = lineEnd.latitude;
    final y2 = lineEnd.longitude;
    
    final numerator = ((y2 - y1) * x - (x2 - x1) * y + x2 * y1 - y2 * x1).abs();
    final denominator = Math.sqrt(Math.pow(y2 - y1, 2) + Math.pow(x2 - x1, 2));
    
    return denominator == 0 ? 0 : numerator / denominator;
  }

  /// Gera uma cor para a polilinha baseada na velocidade
  static int getColorForSpeed(double speedKmh) {
    // Verde: < 30 km/h
    // Amarelo: 30-60 km/h
    // Laranja: 60-90 km/h
    // Vermelho: > 90 km/h
    
    if (speedKmh < 30) {
      return 0xFF00FF00; // Verde
    } else if (speedKmh < 60) {
      return 0xFFFFFF00; // Amarelo
    } else if (speedKmh < 90) {
      return 0xFFFF8800; // Laranja
    } else {
      return 0xFFFF0000; // Vermelho
    }
  }

  /// Formata informações da rota para exibição
  static String formatRouteInfo(RouteData route) {
    final buffer = StringBuffer();
    
    buffer.writeln('=== Informações da Rota ===');
    buffer.writeln('De: ${route.origin.title ?? "Origem"}');
    buffer.writeln('Para: ${route.destination.title ?? "Destino"}');
    buffer.writeln('Distância: ${route.distanceKm}');
    buffer.writeln('Tempo: ${route.durationFormatted}');
    buffer.writeln('Modo: ${route.travelMode}');
    
    if (route.waypoints.isNotEmpty) {
      buffer.writeln('Pontos intermediários: ${route.waypoints.length}');
    }
    
    return buffer.toString();
  }

  /// Valida se uma rota é válida
  static bool isValidRoute(RouteData route) {
    try {
      if (route.origin.latitude == route.destination.latitude &&
          route.origin.longitude == route.destination.longitude) {
        developer.log('Rota inválida: origem e destino são iguais');
        return false;
      }
      
      if (route.polylinePoints == null || route.polylinePoints!.isEmpty) {
        developer.log('Rota inválida: sem pontos de polilinha');
        return false;
      }
      
      if (route.distance == null || route.distance! <= 0) {
        developer.log('Rota inválida: distância inválida');
        return false;
      }
      
      return true;
    } catch (e) {
      developer.log('Erro ao validar rota', error: e);
      return false;
    }
  }
}

/// Classe auxiliar para operações matemáticas
class Math {
  static double sin(double x) => (x as double).sin;
  static double cos(double x) => (x as double).cos;
  static double sqrt(double x) => (x as double).sqrt;
  static double pow(double x, double y) => (x as double).pow(y);
  static double atan2(double y, double x) => (y as double).atan2(x as double);
  static double min(double a, double b) => a < b ? a : b;
  static double max(double a, double b) => a > b ? a : b;
}

// Extensão para adicionar métodos matemáticos ao double
extension DoubleMath on double {
  double sin() => (this * 3.14159265359 / 180);
  double cos() => (this * 3.14159265359 / 180);
  double sqrt() => (this as double).sqrt;
  double pow(double y) => (this as double).pow(y);
  double atan2(double x) => (this as double).atan2(x as double);
}
